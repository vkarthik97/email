
public class Salary {

	public static void main(String[] args) {
		 double annualSalary = 10000;
		 double monthlySalary = annualSalary/12;
		 double inhand = (0.8944 * monthlySalary);
		 double other  = (0.1056 * monthlySalary);
		 double pf = (0.0385 * inhand);
		 double gratuity=(0.015 * inhand);
		 double basicSal = (0.3209 * inhand);
		 double hra = (0.1604 * inhand);
		 double conveyance = (0.0513 * inhand);
		 double medical = (0.0401 * inhand);
		 double adhoc = (0.3342 * inhand);
		 double meal = (0.0388 * inhand);
		 double subTotalAMonthly = (basicSal+hra+conveyance+medical+adhoc+meal);
		 double subTotalAAnnual = (subTotalAMonthly*12);
		 double subTotalBMonthly = (pf + gratuity) ;
		 double subTotalBAnnual = (subTotalBMonthly * 12);
		 double TotalAnnual = (subTotalAAnnual+subTotalBAnnual);
		 double TotalMonthly = (subTotalAMonthly+subTotalBMonthly);
		 double variablePay = (0.9062 * other);
		 double medicalPremium = (0.0937 * other);
		 double grandTotal = (subTotalAAnnual+subTotalBAnnual+variablePay+medicalPremium);
		 
		 System.out.println(grandTotal);
		 
		 
		
	}
}
